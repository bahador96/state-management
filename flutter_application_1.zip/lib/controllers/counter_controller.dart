import 'package:get/get.dart';

class ConunterController extends GetxController {
  int counter = 0;
  void increment() {
    counter++;
    update();
  }
}
