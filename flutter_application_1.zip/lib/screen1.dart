import 'package:flutter/material.dart';
import 'package:flutter_application_1/controllers/counter_controller.dart';
import 'package:get/get.dart';

class Screen1 extends StatelessWidget {
  // const Screen1({Key? key}) : super(key: key);
  var controller = Get.put(ConunterController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          controller.increment();
        },
        child: const Icon(Icons.add),
      ),
      appBar: AppBar(
        title: const Text('GetX Navigations'),
        centerTitle: true,
        elevation: 0,
      ),
      body: SizedBox(
        width: Get.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GetBuilder<ConunterController>(
              builder: (value) {
                return Text(
                  controller.counter.toString(),
                  style: const TextStyle(fontSize: 30),
                );
              },
            ),
            ElevatedButton(
              onPressed: () {
                Get.offNamed('/screen2');
              },
              child: const Text('Go to screen 2'),
            )
          ],
        ),
      ),
    );
  }
}
